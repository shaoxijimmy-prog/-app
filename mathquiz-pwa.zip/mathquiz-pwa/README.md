# Daily Maths PWA · NZ & Australian Curriculum

每日数学练习 · Year 1–13

## Files
- `index.html` — Main app (all logic included)
- `manifest.json` — PWA manifest (makes it installable)
- `sw.js` — Service worker (offline support)
- `icons/` — App icons

## Deploy (Free options)

### Option 1: Netlify (Recommended, free)
1. Go to https://netlify.com and sign up free
2. Drag the entire `mathquiz-pwa` folder onto the Netlify dashboard
3. Done! You get a URL like `https://your-app.netlify.app`
4. Optional: connect a custom domain (e.g. dailymaths.co.nz)

### Option 2: GitHub Pages (Free)
1. Create a GitHub account at https://github.com
2. Create a new repository (e.g. `daily-maths`)
3. Upload all files
4. Go to Settings → Pages → Source: main branch
5. URL: `https://yourusername.github.io/daily-maths`

### Option 3: Vercel (Free)
1. Go to https://vercel.com
2. Import your GitHub repo or drag and drop files
3. Auto-deploys on every update

## Add to Home Screen (iPhone/Android)

### iPhone (Safari):
1. Open the app URL in Safari
2. Tap the Share button (box with arrow)
3. Scroll down → tap "Add to Home Screen"
4. Tap "Add" — app appears on home screen!

### Android (Chrome):
1. Open the app URL in Chrome
2. Tap the 3-dot menu → "Add to Home screen"
3. Or wait for the install banner to appear

## Customise
All questions are in `index.html` in the `gen` object.
Add new question types by adding functions to any year's array.

## Features
- Year 1–13 NZ & Australian curriculum
- 10 random questions per session
- Instant feedback with correct answers
- Score review after each session
- Offline support (works without internet after first load)
- Dark/light mode (follows system)
- Installable on iPhone, Android, Mac, Windows
